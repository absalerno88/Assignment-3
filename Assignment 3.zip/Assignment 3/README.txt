I use g++ and VSC
In the terminal run:

g++ -o Testing main.cpp ExpressionManager.cpp
./Testing

This will start the program and the testing is very straightforward.
I have included a TestPrompts.txt with simple infix expressions to test all of the functions.
type "quit" to end ExpressionManager testing and begin Queue testing.

The Queue testing has a simple menu that you can interact with the numbers 1-6 to test different functions. 
Input of 6 will end Queue testing and the program.

Also I have included screenshots of myself running the program and testing the functions.

ExpressionManagerTesting.png shows the tests of the Q1 stack part of the assignment
QueueTesting1.png and QueueTesting2.png show the testing of the Q2 queue part of the assignment.